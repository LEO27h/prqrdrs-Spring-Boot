package edu.java.udem.prqrdrs.prqrdrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrqrdrsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrqrdrsApplication.class, args);
	}

}
